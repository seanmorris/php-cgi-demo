import controller_0 from "../ux-live-component/live_controller.js";
import "../ux-live-component/live.min.css";
export const eagerControllers = {"live": controller_0};
export const lazyControllers = {"login": () => import("../../controllers/login-controller.js")};
export const isApplicationDebug = true;
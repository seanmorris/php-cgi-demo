# Bootswatch Flatly

This directory holds a copy of the Bootswatch Flatly source code. We can't use
the CSS directly, as it *always* loads a Google font. So, we embed the sass and
override the font import with Sass variables.
